import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class Davaleba5 {
    public static void main(String[] args){
//        List<Integer> numbers = List.of(4, 3, 9, 7, 1, 6);
//        Optional<Integer> secomdSmallest = numbers
//                .stream()
//                .sorted()
//                .skip(1)
//                .findFirst();
//        System.out.println(secomdSmallest.get());


        List<Integer> numbers = List.of(4, 3, 9, 7, 1, 6);
        Optional<Integer> secondLargest = numbers
                .stream()
                .sorted(Comparator.reverseOrder())
                .skip(1)
                .findFirst();
        System.out.println(secondLargest.get());

    }
}
