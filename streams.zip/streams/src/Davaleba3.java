import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Davaleba3 {
    public static void main(String[] args){
        List<String> words = List.of("ixvi", "bunny", "cat", "tree", "Cherry", "Kiwi");

        Set<String> sortedSet = words.stream()
                .sorted()
                .collect(Collectors.toCollection(java.util.LinkedHashSet::new));

        System.out.println(sortedSet);
    }
}
