import java.io.*;

public class Davaleba1 {
    public static void main(String[] args) {
        String fileName = "/Users/mziapitskhelauri/Desktop/streams/src/nini.txt";
        int finalInt = 0;

        try (NumberReader reader = new NumberReader(fileName)){
            int tempInt = 0;

            while ((tempInt = reader.ReadInt()) != -1){
                if (tempInt < 10)
                    continue;

                finalInt += tempInt*tempInt;
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        // yay!
        System.out.println(finalInt);
    }
}

class NumberReader implements AutoCloseable {
    FileReader reader = null;
    boolean isClosed = false;

    public NumberReader(String filename) throws IOException {
        reader = new FileReader(filename);
    }

    public int ReadInt() throws IOException {
        if (isClosed || reader == null)
            return -1;

        int integer = 0;

        int c = 0;

        while ((c = reader.read()) != -1 && c != 32) {
            integer *= 10;
            integer += (c - 48);
        }

        if (c == -1)
            close();

        return integer;
    }

    @Override
    public void close() throws IOException {
        if (reader == null)
            return;

        reader.close();
        isClosed = true;
    }
}