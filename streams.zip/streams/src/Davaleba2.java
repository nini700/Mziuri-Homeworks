import java.io.*;
import java.util.*;

public class Davaleba2 {
    public static void main(String[] args) {
        String fileName = "C:\\Users\\alex\\Documents\\test.txt";
        List<String> words = new ArrayList<>();

        try (WordReader reader = new WordReader(fileName)){
            String tempString = "";

            while ((tempString = ReadSpecialWord(reader)) != null) {
                if (tempString == "")
                    continue;

                words.add(tempString);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        // yay!
        for (String word : words) {
            System.out.println(word);
        }
    }

    private static String ReadSpecialWord(WordReader reader) throws IOException {
        String word = reader.ReadWord();

        if (word == null)
            return null;

        if (word.charAt(0) != 'j' && word.charAt(0) != 'J')
            return "";

        StringBuilder builder = new StringBuilder(word);

        for (int i = 0; i < builder.length(); i++) {
            char c = builder.charAt(i);
            // convert to uppercase
            builder.setCharAt(i, (char)(c & 0x5f));
        }

        return builder.toString();
    }
}

class WordReader implements AutoCloseable {
    FileReader reader = null;
    boolean isClosed = false;

    public WordReader(String filename) throws IOException {
        reader = new FileReader(filename);
    }

    public String ReadWord() throws IOException {
        if (isClosed || reader == null)
            return null;

        char[] buffer = new char[256];
        int len = 0;
        int c = 0;

        while ((c = reader.read()) != -1 && c != 32)
            buffer[len++] = (char) c;

        if (c == -1)
            close();

        return new String(buffer, 0, len);
    }

    @Override
    public void close() throws IOException {
        if (reader == null)
            return;

        reader.close();
        isClosed = true;
    }
}