import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Davaleba4 {
    public static void main(String[] args){
        List<Human> people = new ArrayList<>();
        people.add(new Human("Levani", 17));
        people.add(new Human("Nini", 16));
        people.add(new Human("Ana", 33));
        people.add(new Human("Dali", 30));
        people.add(new Human("Tako", 9));
        boolean hasLevani = people
                .stream()
                .filter(person -> person.getAge() >= 15)
                .anyMatch(person -> person.getName().equals("Levani"));
        System.out.println(hasLevani);
    }
}